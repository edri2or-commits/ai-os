from fastapi import APIRouter, HTTPException
from models.schemas import (
    ReadFileRequest, ReadFileResponse,
    ListTreeRequest, ListTreeResponse,
    OpenPRRequest, OpenPRResponse
)
from core.mcp_client import MCPGitHubClient
from core.openai_client import OpenAIClient

router = APIRouter()
mcp = MCPGitHubClient()
ai = OpenAIClient()

@router.post("/read-file", response_model=ReadFileResponse)
async def read_file(req: ReadFileRequest):
    result = await mcp.read_file(req.owner, req.repo, req.path)
    if not result["ok"]:
        raise HTTPException(status_code=result.get("status_code", 500), detail=result)
    return result

@router.post("/list-tree", response_model=ListTreeResponse)
async def list_tree(req: ListTreeRequest):
    result = await mcp.list_tree(req.owner, req.repo, req.path, req.depth)
    if not result["ok"]:
        raise HTTPException(status_code=result.get("status_code", 500), detail=result)
    return result

@router.post("/open-pr", response_model=OpenPRResponse)
async def open_pr(req: OpenPRRequest):
    file_data = await mcp.read_file(req.owner, req.repo, req.file_path)
    if not file_data["ok"]:
        return file_data

    new_content = await ai.generate_file_update(
        original_content=file_data["content"],
        change_instructions=req.change_instructions
    )

    pr_result = await mcp.open_pr(
        owner=req.owner,
        repo=req.repo,
        base_branch=req.base_branch,
        target_branch=req.target_branch,
        file_path=req.file_path,
        new_content=new_content,
        pr_title=req.pr_title,
        pr_body=req.pr_body,
        allow_large_diff=req.allow_large_diff
    )
    return pr_result
