# ai-os-mcp-github-client

A FastAPI-based service acting as an MCP Client for the official GitHub MCP Server.
It allows GPT-based systems to interact with repositories **only via Pull Requests**.

## Run locally
```bash
uvicorn services.mcp_github_client.main:app --port 8081 --reload
```

## ENV variables
```
GITHUB_MCP_URL=https://github-mcp-server.local:8080
GITHUB_PERSONAL_ACCESS_TOKEN=ghp_xxx
OPENAI_API_KEY=sk-xxx
OPENAI_MODEL=gpt-4o-mini
```

## Endpoints
- POST /github/read-file
- POST /github/list-tree
- POST /github/open-pr

## Tests
```bash
pytest services/mcp_github_client/tests/
```
