from pydantic import BaseModel
from typing import List, Optional, Dict

class ReadFileRequest(BaseModel):
    owner: str
    repo: str
    path: str

class ListTreeRequest(BaseModel):
    owner: str
    repo: str
    path: str
    depth: int = 1

class OpenPRRequest(BaseModel):
    owner: str
    repo: str
    base_branch: str
    target_branch: str
    file_path: str
    change_instructions: str
    pr_title: str
    pr_body: str
    allow_large_diff: bool = False

class ReadFileResponse(BaseModel):
    ok: bool
    owner: Optional[str] = None
    repo: Optional[str] = None
    path: Optional[str] = None
    sha: Optional[str] = None
    size: Optional[int] = None
    encoding: Optional[str] = "utf-8"
    content: Optional[str] = None
    html_url: Optional[str] = None
    error_type: Optional[str] = None
    message: Optional[str] = None
    status_code: Optional[int] = None
    details: Optional[Dict] = None

class ListTreeResponse(BaseModel):
    ok: bool
    owner: Optional[str]
    repo: Optional[str]
    root_path: Optional[str]
    depth: Optional[int]
    entries: Optional[List[Dict]]
    error_type: Optional[str] = None
    message: Optional[str] = None
    status_code: Optional[int] = None
    details: Optional[Dict] = None

class OpenPRResponse(BaseModel):
    ok: bool
    owner: Optional[str]
    repo: Optional[str]
    base_branch: Optional[str]
    target_branch: Optional[str]
    file_path: Optional[str]
    commit_sha: Optional[str]
    pr_number: Optional[int]
    pr_url: Optional[str]
    summary: Optional[str]
    error_type: Optional[str] = None
    message: Optional[str] = None
    status_code: Optional[int] = None
    details: Optional[Dict] = None
