import aiohttp
import logging
from config import settings

logger = logging.getLogger(__name__)

class MCPGitHubClient:
    def __init__(self):
        self.base_url = settings.github_mcp_url
        self.headers = {
            "Authorization": f"Bearer {settings.github_pat}",
            "Content-Type": "application/json"
        }

    async def _call_mcp(self, tool: str, params: dict):
        url = f"{self.base_url}/tools/{tool}"
        logger.info(f"Calling MCP tool={tool}, params={params}")
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(url, json=params, headers=self.headers) as resp:
                    data = await resp.json()
                    return data
            except Exception as e:
                logger.error(f"MCP call failed: {e}")
                return {"ok": False, "error_type": "mcp_error", "message": str(e), "status_code": 500}

    async def read_file(self, owner: str, repo: str, path: str):
        return await self._call_mcp("repos/files/read", {"owner": owner, "repo": repo, "path": path})

    async def list_tree(self, owner: str, repo: str, path: str, depth: int):
        return await self._call_mcp("repos/tree/list", {"owner": owner, "repo": repo, "path": path, "depth": depth})

    async def open_pr(self, **kwargs):
        return await self._call_mcp("repos/prs/open", kwargs)
