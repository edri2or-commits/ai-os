import openai
import logging
from config import settings

logger = logging.getLogger(__name__)
openai.api_key = settings.openai_api_key

class OpenAIClient:
    async def generate_file_update(self, original_content: str, change_instructions: str):
        prompt = f"""אתה עורך קובץ GitHub.
תוכן קיים:
{original_content[:6000]}
---
הוראות:
{change_instructions}
כתוב תוכן חדש מלא לקובץ.
"""
        try:
            response = openai.chat.completions.create(
                model=settings.openai_model,
                messages=[
                    {"role": "system", "content": "אתה עוזר טכני אחראי, הפועל דרך MCP לשינויים מבוקרים בקוד."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=4000,
                timeout=45
            )
            content = response.choices[0].message["content"]
            logger.info("OpenAI content generated successfully")
            return content
        except Exception as e:
            logger.error(f"OpenAI generation failed: {e}")
            return f"ERROR: {e}"
