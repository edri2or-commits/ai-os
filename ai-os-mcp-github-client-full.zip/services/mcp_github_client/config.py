from pydantic import BaseSettings

class Settings(BaseSettings):
    github_mcp_url: str
    github_pat: str
    openai_api_key: str
    openai_model: str = "gpt-4o-mini"
    service_port: int = 8081
    log_level: str = "INFO"

    class Config:
        env_file = ".env"

settings = Settings()
