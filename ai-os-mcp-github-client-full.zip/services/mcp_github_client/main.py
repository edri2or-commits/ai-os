from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from api.routes_github import router as github_router

app = FastAPI(title="AI-OS MCP GitHub Client", version="1.0.0")

app.include_router(github_router, prefix="/github")

@app.get("/")
async def root():
    return {"ok": True, "service": "ai-os-mcp-github-client", "status": "ready"}

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={
            "ok": False,
            "error_type": "internal_error",
            "message": str(exc),
            "status_code": 500
        }
    )
