import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_read_file_mock(monkeypatch):
    async def mock_read_file(owner, repo, path):
        return {"ok": True, "owner": owner, "repo": repo, "path": path, "content": "dummy content"}
    monkeypatch.setattr("core.mcp_client.MCPGitHubClient.read_file", mock_read_file)
    response = client.post("/github/read-file", json={"owner": "edri2or-commits", "repo": "ai-os", "path": "docs/SYSTEM_SNAPSHOT.md"})
    assert response.status_code == 200
    assert response.json()["ok"] is True
